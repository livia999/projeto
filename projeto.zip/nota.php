<!DOCTYPE html>
<?php 
    include_once "conf/default.inc.php";
    require_once "conf/Conexao.php";
    $title = "Lista de Notas";
    $tipo = isset($_POST['tipo']) ? $_POST['tipo'] : "2";
    $procurar = isset($_POST['procurar']) ? $_POST['procurar'] : "";
?>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <title> <?php echo $title; ?> </title>
</head>
<body>
<?php include "menu.php"; ?>
</br></br>
<form method="post">

<label for= "pesquisar"> Pesquisar por: </label> <br><br>

<input type="radio" id="tipo" name="tipo" value="1"
<?php if($tipo == 1) echo 'checked'; ?>> ID 

<br>

<input type="radio" id="tipo" name="tipo" value="2"
<?php if($tipo == 2) echo 'checked'; ?>> Título

<br>

<input type="radio" id="tipo" name="tipo" value="3"
<?php if($tipo == 3) echo 'checked'; ?>> Texto

<br>

<input type="radio" id="tipo" name="tipo" value="4"
<?php if($tipo == 4) echo 'checked'; ?>> Cor

<br>

<input type="radio" id="tipo" name="tipo" value="5"
<?php if($tipo == 5) echo 'checked'; ?>> Status

<input type="submit" value="Consultar">
    
<br><br><br>


<fieldset>
        <legend>Procurar</legend>
        <input type="text"   name="procurar" id="procurar" size="37" value="<?php echo $procurar;?>">
        <input type="submit" name="acao"     id="acao">
        <br><br>

</form>
<br>
<?php
    $sql = "";
    if ($tipo == 1){
        $sql = "SELECT * FROM nota WHERE id LIKE '$procurar%' ORDER BY id";
    }

    if ($tipo ==2){    
        $sql = "SELECT * FROM nota WHERE titulo LIKE '$procurar%' ORDER BY titulo";
    }
    
    if ($tipo ==3){
        $sql = "SELECT * FROM nota WHERE texto LIKE '$procurar%' ORDER BY texto";
    }

    if ($tipo ==4){
        $sql = "SELECT * FROM nota WHERE cor LIKE '$procurar%' ORDER BY cor";
    }

    if ($tipo ==5){
        $sql = "SELECT * FROM nota WHERE status LIKE '$procurar%' ORDER BY status";
    }

$pdo = Conexao::getInstance();
$consulta = $pdo->query($sql);
while ($linha = $consulta->fetch(PDO::FETCH_ASSOC)) {
 
?>

<tr><td><?php echo "ID: {$linha['id']} <br>  Título: {$linha['titulo']}  <br> Texto: {$linha['texto']} <br> Cor: {$linha['cor']} <br> Status: {$linha['status']}<br><br>";
    
?>
        <?php  
}
?> 



</body>
</html>