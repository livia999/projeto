<center>
<table>
    
<tr>
    <td><a href="user.php"> Usuário </a></td>
    <td><a href="endereco.php"> Endereço </a></td>
    <td><a href="nota.php"> Notas </a></td>
    <td><a href="rotulo.php"> Rótulo </a></td>
</tr>

</table>    
</center>
<br><br>