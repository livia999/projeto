<!DOCTYPE html>
<?php 
    include_once "conf/default.inc.php";
    require_once "conf/Conexao.php";
    $title = "Lista de Usuários";
    $tipo = isset($_POST['tipo']) ? $_POST['tipo'] : "3";
    $procurar = isset($_POST['procurar']) ? $_POST['procurar'] : "";
?>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <title> <?php echo $title; ?> </title>
</head>
<body>
<?php include "menu.php"; ?>
</br></br>
<form method="post">

<label for= "pesquisar"> Pesquisar por: </label> <br><br>

<input type="radio" id="tipo" name="tipo" value="1"
<?php if($tipo == 1) echo 'checked'; ?>> ID 

<br>

<input type="radio" id="tipo" name="tipo" value="2"
<?php if($tipo == 2) echo 'checked'; ?>> User

<br>

<input type="radio" id="tipo" name="tipo" value="3"
<?php if($tipo == 3) echo 'checked'; ?>> Pass

<input type="submit" value="Consultar">
    
<br><br><br>


<fieldset>
        <legend>Procurar</legend>
        <input type="text"   name="procurar" id="procurar" size="37" value="<?php echo $procurar;?>">
        <input type="submit" name="acao"     id="acao">
        <br><br>

</form>
<br>
<?php
    $sql = "";
    if ($tipo == 1){
        $sql = "SELECT * FROM user WHERE id = $procurar ORDER BY id";
    }

    if ($tipo ==2){    
        $sql = "SELECT * FROM user WHERE user LIKE '$procurar%' ORDER BY user";
    }
    
    if ($tipo ==3){
        $sql = "SELECT * FROM user WHERE pass LIKE '$procurar%' ORDER BY pass";
    }


$pdo = Conexao::getInstance();
$consulta = $pdo->query($sql);
while ($linha = $consulta->fetch(PDO::FETCH_ASSOC)) {
 
?>

<tr><td><?php echo "ID: {$linha['id']} <br>  User: {$linha['user']}  <br> Senha: {$linha['pass']} <br><br>";
    
?>
        <?php  
}
?> 



</body>
</html>